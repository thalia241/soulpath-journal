import {
  Animated,
  Easing,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  useEffect,
  useRef,
} from "react";

import {
  colors,
  fonts,
} from "../theme";

type Props = {
  onFinished: () => void;
};

export default function AnimatedSoulPathLaunch({
  onFinished,
}: Props) {
  const containerOpacity =
    useRef(
      new Animated.Value(1)
    ).current;

  const starOpacity =
    useRef(
      new Animated.Value(0)
    ).current;

  const starScale =
    useRef(
      new Animated.Value(0.7)
    ).current;

  const pathOpacity =
    useRef(
      new Animated.Value(0)
    ).current;

  const pathTranslateY =
    useRef(
      new Animated.Value(20)
    ).current;

  const titleOpacity =
    useRef(
      new Animated.Value(0)
    ).current;

  const titleTranslateY =
    useRef(
      new Animated.Value(10)
    ).current;

  const taglineOpacity =
    useRef(
      new Animated.Value(0)
    ).current;

  useEffect(() => {
    const sequence =
      Animated.sequence([
        Animated.parallel([
          Animated.timing(
            starOpacity,
            {
              toValue: 1,
              duration: 450,
              easing:
                Easing.out(
                  Easing.cubic
                ),
              useNativeDriver:
                true,
            }
          ),

          Animated.spring(
            starScale,
            {
              toValue: 1,
              friction: 7,
              tension: 45,
              useNativeDriver:
                true,
            }
          ),
        ]),

        Animated.parallel([
          Animated.timing(
            pathOpacity,
            {
              toValue: 1,
              duration: 400,
              easing:
                Easing.out(
                  Easing.cubic
                ),
              useNativeDriver:
                true,
            }
          ),

          Animated.timing(
            pathTranslateY,
            {
              toValue: 0,
              duration: 500,
              easing:
                Easing.out(
                  Easing.cubic
                ),
              useNativeDriver:
                true,
            }
          ),

          Animated.timing(
            titleOpacity,
            {
              toValue: 1,
              duration: 400,
              useNativeDriver:
                true,
            }
          ),

          Animated.timing(
            titleTranslateY,
            {
              toValue: 0,
              duration: 450,
              easing:
                Easing.out(
                  Easing.cubic
                ),
              useNativeDriver:
                true,
            }
          ),
        ]),

        Animated.timing(
          taglineOpacity,
          {
            toValue: 1,
            duration: 350,
            useNativeDriver:
              true,
          }
        ),

        Animated.delay(450),

        Animated.timing(
          containerOpacity,
          {
            toValue: 0,
            duration: 350,
            easing:
              Easing.inOut(
                Easing.cubic
              ),
            useNativeDriver:
              true,
          }
        ),
      ]);

    sequence.start(
      ({ finished }) => {
        if (finished) {
          onFinished();
        }
      }
    );

    return () => {
      sequence.stop();
    };
  }, [
    containerOpacity,
    onFinished,
    pathOpacity,
    pathTranslateY,
    starOpacity,
    starScale,
    taglineOpacity,
    titleOpacity,
    titleTranslateY,
  ]);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          opacity:
            containerOpacity,
        },
      ]}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      pointerEvents="none"
    >
      <View
        style={
          styles.center
        }
      >
        <Animated.Text
          style={[
            styles.star,
            {
              opacity:
                starOpacity,

              transform: [
                {
                  scale:
                    starScale,
                },
              ],
            },
          ]}
        >
          ✦
        </Animated.Text>

        <Animated.View
          style={[
            styles.pathContainer,
            {
              opacity:
                pathOpacity,

              transform: [
                {
                  translateY:
                    pathTranslateY,
                },
              ],
            },
          ]}
        >
          <Text
            style={
              styles.path
            }
          >
            ︶
          </Text>

          <Text
            style={
              styles.pathMiddle
            }
          >
            〜
          </Text>

          <Text
            style={
              styles.pathBottom
            }
          >
            ﹏
          </Text>
        </Animated.View>

        <Animated.Text
          style={[
            styles.title,
            {
              opacity:
                titleOpacity,

              transform: [
                {
                  translateY:
                    titleTranslateY,
                },
              ],
            },
          ]}
        >
          SoulPath
        </Animated.Text>

        <Animated.Text
          style={[
            styles.tagline,
            {
              opacity:
                taglineOpacity,
            },
          ]}
        >
          A private space for the
          journey within.
        </Animated.Text>
      </View>
    </Animated.View>
  );
}

const styles =
  StyleSheet.create({
    container: {
      ...StyleSheet.absoluteFillObject,

      zIndex: 9999,

      backgroundColor:
        colors.background,

      alignItems:
        "center",

      justifyContent:
        "center",
    },

    center: {
      alignItems:
        "center",

      justifyContent:
        "center",

      paddingHorizontal:
        32,
    },

    star: {
      color:
        colors.gold,

      fontSize: 48,

      lineHeight: 58,

      textShadowColor:
        "rgba(188, 166, 232, 0.75)",

      textShadowRadius:
        20,

      textShadowOffset: {
        width: 0,
        height: 0,
      },
    },

    pathContainer: {
      alignItems:
        "center",

      marginTop: -3,
      marginBottom: 14,
    },

    path: {
      color:
        colors.lavender,

      fontSize: 54,

      lineHeight: 42,

      transform: [
        {
          rotate:
            "-10deg",
        },
      ],
    },

    pathMiddle: {
      color:
        colors.lavenderStrong,

      fontSize: 61,

      lineHeight: 43,

      marginTop: -18,

      transform: [
        {
          rotate:
            "8deg",
        },
      ],
    },

    pathBottom: {
      color:
        colors.purple,

      fontSize: 72,

      lineHeight: 47,

      marginTop: -18,

      transform: [
        {
          rotate:
            "-7deg",
        },
      ],
    },

    title: {
      color:
        colors.text,

      fontFamily:
        fonts.display,

      fontSize: 44,

      lineHeight: 50,

      marginTop: 6,
    },

    tagline: {
      color:
        colors.goldSoft,

      fontFamily:
        fonts.displayItalic,

      fontSize: 16,

      lineHeight: 22,

      textAlign:
        "center",

      maxWidth: 280,

      marginTop: 4,
    },
  }); 